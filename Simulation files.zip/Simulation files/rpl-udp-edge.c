/*
 * RPL UDP EDGE Client
 * Sends packets to its RPL parent (server), not directly to root.
 *
 * Collects:
 *   - latency
 *   - ETX
 *   - energy
 *   - load
 *   - fitness
 */

#include "contiki.h"
#include "net/routing/routing.h"
#include "random.h"
#include "net/netstack.h"
#include "net/ipv6/simple-udp.h"

#include "sys/log.h"
#include "sys/clock.h"
#include "sys/node-id.h"
#include "sys/etimer.h"

#include "net/ipv6/uip-ds6-route.h"
#include "net/ipv6/uip-ds6-nbr.h"
#include "net/link-stats.h"

#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

#define LOG_MODULE "EDGE"
#define LOG_LEVEL LOG_LEVEL_INFO

#define UDP_CLIENT_PORT 8765
#define UDP_SERVER_PORT 5678
#define SEND_INTERVAL (10 * CLOCK_SECOND)

/* Virtual energy model */
#define TX_COST 2
#define RX_COST 1

static struct simple_udp_connection udp_conn;

static uint32_t rx_count = 0;
static uint32_t tx_count = 0;

static clock_time_t last_tx_time = 0;
static uint32_t last_latency_ms = 0;

static uint32_t etx_sum = 0;
static uint32_t etx_samples = 0;

/* ------------------------------ GET ETX ------------------------------ */
static uint16_t
get_path_etx_scaled(void)
{
  const uip_ipaddr_t *parent_ip = uip_ds6_defrt_choose();
  if(parent_ip == NULL) return 0;

  uip_ds6_nbr_t *nbr = uip_ds6_nbr_lookup(parent_ip);
  if(nbr == NULL) return 0;

  const struct link_stats *st = link_stats_from_lladdr((const linkaddr_t *)uip_ds6_nbr_get_ll(nbr));
  if(st == NULL) return 0;

  return st->etx;
}

/* ------------------------------ ENERGY ------------------------------ */
static uint32_t
get_virtual_energy(void)
{
  return tx_count * TX_COST + rx_count * RX_COST;
}

/* ------------------------------ OBJECTIVE ------------------------------ */
static uint32_t
compute_objective(void)
{
  uint32_t avg_etx = etx_samples ? (etx_sum / etx_samples) : 0;
  return avg_etx + get_virtual_energy();
}

/* ------------------------------ PRINT RESULT ------------------------------ */
static void
print_edge_result(void)
{
  uint32_t avg_etx = etx_samples ? (etx_sum / etx_samples) : 0;

  LOG_INFO("RESULT_EDGE: node=%u latency_ms=%" PRIu32
           " etx=%" PRIu32 " energy=%" PRIu32
           " load=%" PRIu32 " fitness=%" PRIu32 "\n",
           node_id,
           last_latency_ms,
           avg_etx,
           get_virtual_energy(),
           rx_count,
           compute_objective());
}

/* ------------------------------ RX CALLBACK ------------------------------ */
static void
udp_rx_callback(struct simple_udp_connection *c,
                const uip_ipaddr_t *sender_addr,
                uint16_t sender_port,
                const uip_ipaddr_t *receiver_addr,
                uint16_t receiver_port,
                const uint8_t *data,
                uint16_t datalen)
{
  clock_time_t now = clock_time();
  rx_count++;

  if(last_tx_time != 0) {
    uint32_t ticks = now - last_tx_time;
    last_latency_ms = (ticks * 1000UL) / CLOCK_SECOND;
  }

  uint16_t etx_now = get_path_etx_scaled();
  if(etx_now > 0) {
    etx_sum += etx_now;
    etx_samples++;
  }

  print_edge_result();
}

/* ------------------------------ PROCESS ------------------------------ */
PROCESS(udp_client_process, "UDP EDGE Client");
AUTOSTART_PROCESSES(&udp_client_process);

PROCESS_THREAD(udp_client_process, ev, data)
{
  static struct etimer periodic_timer;
  static uint32_t time_stamp;
  uip_ipaddr_t dest;

  PROCESS_BEGIN();

  simple_udp_register(&udp_conn, UDP_CLIENT_PORT, NULL,
                      UDP_SERVER_PORT, udp_rx_callback);

  etimer_set(&periodic_timer, SEND_INTERVAL);

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));

    const uip_ipaddr_t *parent_ip = uip_ds6_defrt_choose();

    if(parent_ip != NULL) {
      uip_ipaddr_copy(&dest, parent_ip);

      time_stamp = clock_time();
      last_tx_time = time_stamp;

      simple_udp_sendto(&udp_conn, &time_stamp, sizeof(time_stamp), &dest);
      tx_count++;

    } else {
      LOG_INFO("No RPL parent yet\n");
    }

    etimer_reset(&periodic_timer);
  }

  PROCESS_END();
}

