/*
 * Unified ROOT + SERVER for Contiki-NG (RPL-Lite)
 *
 * node_id == 1 → ROOT
 * node_id != 1 → SERVER
 *
 * Metrics:
 *   latency_ms
 *   etx (servers only)
 *   energy
 *   load
 *   fitness (servers only)
 */

#include "contiki.h"
#include "net/netstack.h"
#include "net/routing/routing.h"
#include "net/ipv6/simple-udp.h"
#include "net/routing/rpl-lite/rpl.h"
#include "net/ipv6/uip-ds6.h"

#include "sys/log.h"
#include "sys/node-id.h"
#include "sys/etimer.h"

#include <string.h>
#include <stdint.h>
#include <inttypes.h>

#define LOG_MODULE "SrvRoot"
#define LOG_LEVEL LOG_LEVEL_INFO

#define UDP_CLIENT_PORT 8765
#define UDP_SERVER_PORT 5678

/* Virtual energy model */
#define RX_COST 1
#define TX_COST 2

/* Objective function weights */
#define ALPHA 0.25
#define BETA  0.25
#define GAMMA 0.25
#define DELTA 0.25

static struct simple_udp_connection udp_conn;

/* Metrics */
static uint32_t req_count = 0;  // packets received
static uint32_t resp_count = 0; // packets sent
static uint32_t last_latency_ms = 0;

/* -------------------------------- ENERGY -------------------------------- */
static uint32_t
get_virtual_energy(void)
{
  return (req_count * RX_COST) + (resp_count * TX_COST);
}

/* -------------------------------- ETX (Servers only) -------------------------------- */
static uint16_t
get_server_etx(void)
{
  if(node_id == 1) return 0; /* Root does not compute ETX */

  const uip_ipaddr_t *parent_ip_const = uip_ds6_defrt_choose();
  if(parent_ip_const == NULL)
    return 0;

  uip_ipaddr_t *parent_ip = (uip_ipaddr_t *)parent_ip_const;

  rpl_nbr_t *nbr = rpl_neighbor_get_from_ipaddr(parent_ip);
  if(nbr == NULL)
    return 0;

  return nbr->rank; // Contiki-NG rank ~ ETX*256
}

/* -------------------------------- FITNESS -------------------------------- */
static float
compute_fitness(void)
{
  return (ALPHA * (float)last_latency_ms) +
         (BETA  * (float)get_virtual_energy()) +
         (GAMMA * (float)req_count) +
         (DELTA * (float)get_server_etx());
}

/* -------------------------------- PRINT RESULT -------------------------------- */
static void
print_result(void)
{
  if(node_id == 1) {

    /* ROOT OUTPUT */
    LOG_INFO("RESULT_ROOT: node=%u latency_ms=%" PRIu32
             " energy=%" PRIu32 " load=%" PRIu32 "\n",
             node_id,
             last_latency_ms,
             get_virtual_energy(),
             req_count);

  } else {

    /* SERVER OUTPUT */
    LOG_INFO("RESULT_SERVER: node=%u latency_ms=%" PRIu32
             " etx=%u energy=%" PRIu32 " load=%" PRIu32
             " fitness=%ld\n",
             node_id,
             last_latency_ms,
             get_server_etx(),
             get_virtual_energy(),
             req_count,
             (long)compute_fitness());
  }
}

/* -------------------------------- UDP RX CALLBACK -------------------------------- */
static void
udp_rx_callback(struct simple_udp_connection *c,
                const uip_ipaddr_t *sender_addr,
                uint16_t sender_port,
                const uip_ipaddr_t *receiver_addr,
                uint16_t receiver_port,
                const uint8_t *data,
                uint16_t datalen)
{
  req_count++;

  uint32_t t_client = 0;
  memcpy(&t_client, data, sizeof(uint32_t));

  uint32_t now = clock_time();
  last_latency_ms = (1000UL * (now - t_client)) / CLOCK_SECOND;

  simple_udp_sendto(&udp_conn, data, datalen, sender_addr);
  resp_count++;

  print_result();
}

/* -------------------------------- PROCESS START -------------------------------- */
PROCESS(unified_server_root_process, "Unified ROOT + SERVER");
AUTOSTART_PROCESSES(&unified_server_root_process);

PROCESS_THREAD(unified_server_root_process, ev, data)
{
  static struct etimer periodic;

  PROCESS_BEGIN();

  if(node_id == 1) {
    LOG_INFO("Node %u starting as ROOT\n", node_id);
    NETSTACK_ROUTING.root_start();
  } else {
    LOG_INFO("Node %u starting as SERVER\n", node_id);
  }

  simple_udp_register(&udp_conn,
                      UDP_SERVER_PORT,
                      NULL,
                      UDP_CLIENT_PORT,
                      udp_rx_callback);

  etimer_set(&periodic, 30 * CLOCK_SECOND);

  while(1) {
    PROCESS_WAIT_EVENT();
    if(ev == PROCESS_EVENT_TIMER) {
      print_result();
      etimer_reset(&periodic);
    }
  }

  PROCESS_END();
}

